<?php

namespace App\Models;

class BlogMapTag extends BaseModel
{
    public $timestamps = false;
}
