/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'chart', 'es', {
	bar: 'Barra',
	chart: 'Gráfico',
	chartType: 'Tipo de gráfico:',
	dialogTitle: 'Editar Gráfico',
	doughnut: 'Dona',
	height: 'Alto:',
	label: 'Etiqueta:',
	line: 'Línea',
	pie: 'Circular',
	polar: 'Polar',
	value: 'Valor:'
} );
